مشروع مركز التقنية الذكية - النسخة العربية

الصفحة الرئيسية:
html/index.html

المشروع يحتوي على 6 صفحات لأن متطلبات التكليف تشمل واجهة إنشاء الحساب بالإضافة إلى تسجيل الدخول.

مهم لتجربة Ajax:
افتح start_server.bat على Windows، ثم افتح:
http://localhost:8000/html/index.html

المكتبات المستخدمة:
- Bootstrap 5
- jQuery
- Font Awesome
- Bootstrap Toast
- Ajax بواسطة jQuery

المجلدات:
html = صفحات الموقع
css = التنسيق
js = JavaScript وملفات محتوى Ajax
images = صور الموقع المحلية
videos = الفيديو التعريفي المحلي
